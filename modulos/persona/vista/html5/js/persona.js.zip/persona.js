
/*
 * * * * * * * * * * LICENCIA * * * * * * * * * * * * * * * * * * * * *

Copyright(C) 2015
pensum Universtiario de Tecnología Dr. Federico Rivero Palacio

Este programa es Software Libre y usted puede redistribuirlo y/o modificarlo
bajo los términos de la versión 3.0 de la Licencia Pública General (GPLv3)
publicada por la Free Software Foundation (FSF), es distribuido sin ninguna
garantía. Usted debe haber recibido una copia de la GPLv3 junto con este
programa, sino, puede encontrarlo en la página web de la FSF, 
específicamente en la dirección http://www.gnu.org/licenses/gpl-3.0.html

 * * * * * * * * * * ARCHIVO * * * * * * * * * * * * * * * * * * * * *

Nombre: persona.js
Diseñador:Jean Pierre Sosa.
Programador:Jean Pierre Sosa.
Fecha:10-1-16
Descripción:  
	Este es el javascript del módulo error, encargado de todas las 
	llamadas AJAX, objetos DOM y validaciones de dicho módulo. 

 * * * * * * * * Cambios/Mejoras/Correcciones/Revisiones * * * * * * * *
Diseñador - Programador /   Fecha   / Descripción del cambio
   

 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*/

/**
* Funcion Java Script que permite listar Todos los institutos
* para que luego sea mostado en un select. los datos son enviados
* por ajax para que se haga la consulta a la base de datos y mostrar 
* los resultados en la funcion montarSelectInstituto().
*/
function verInstituto(){

	var arr = Array("m_modulo"	,	"persona",
					"m_accion"	,	"listar",
					"instituto"	,	$("#selectInstituto").val()
					);
		
	ajaxMVC(arr,montarSelectInstituto,error);
}

/**
* Funcion Java Script que permite mostrar un select con
* los institutos y es concatenado a un  div en la vista HTML
*/

function montarSelectInstituto(data){
	var cadena = "";
	cadena += "<select onchange='verPersona();' class='selectpicker' id='selectInstituto' title='institutos' data-live-search='true' data-size='auto' data-max-options='12' >"; 
	cadena += "<option value='seleccionar'>Seleccionar</option>";
	for(var x=0; x<data.instituto.length;x++)
	{
	 	if(data.instituto[x]['codigo']!=11)
	 		cadena += '<option value="'+data.instituto[x]["codigo"]+'">'+data.instituto[x]["nom_corto"]+'</option>';
	 	else
	 		cadena += '<option selected="selected" value="'+data.instituto[x]["codigo"]+'">'+data.instituto[x]["nom_corto"]+'</option>';
	}
	cadena +="</select>";

	$(cadena).appendTo('.clase');
	activarSelect();					
}

/**
* Funcion Java Script que permite listar Todos los PNF
* para que luego sea mostado en un select. los datos son enviados
* por ajax para que se haga la consulta a la base de datos y mostrar 
* los resultados en la funcion montarSelectPNF().
*/
function verPNF(){

	var arr = Array("m_modulo"	,	"persona",
					"m_accion"	,	"listar",
					"pnf"		,	$("#selectPNF").val()								
					);
		
	ajaxMVC(arr,montarSelectPNF,error);
}


/**
* Funcion Java Script que permite mostrar un select con
* los PNF y es concatenado a un  div en la vista HTML
*/
function montarSelectPNF(data){

	var cadena = "";
	cadena += "<select onchange='verPersona();' class='selectpicker' id='selectPNF' title='pensum' data-live-search='true' data-size='auto' data-max-options='12' >"; 
	cadena += "<option value='seleccionar'>Seleccionar</option>";
	for(var x=0; x<data.pnf.length;x++)
	{
		cadena += '<option value="'+data.pnf[x]["codigo"]+'">'+data.pnf[x]["nom_corto"]+'</option>';
	}
	cadena +="</select>";

	$(cadena).appendTo('.clase');
	activarSelect();					
}

/**
* Funcion Java Script que permite listar Todos los estados que posee un actor
* para que luego sea mostado en un select. los datos son enviados
* por ajax para que se haga la consulta a la base de datos y mostrar 
* los resultados en la funcion mmontarSelectEstado().
*/

function verEstado(){

	var arr = Array("m_modulo"	,	"persona",
					"m_accion"	,	"listar",
					"estado"	,	$("#selectEstado").val()				
					);		
	ajaxMVC(arr,montarSelectEstado,error);
}

/**
* Funcion Java Script que permite mostrar un select con
* los estados y es concatenado a un  div en la vista HTML
*/
function montarSelectEstado(data){

	var cadena = "";
	cadena += "<select onchange='verPersona();' class='selectpicker' id='selectEstado' title='pensum' data-live-search='true' data-size='auto' data-max-options='12' >"; 
	cadena += "<option value='seleccionar'>Seleccionar</option>";
	for(var x=0; x<data.estado.length;x++)
	{		
		cadena += '<option value="'+data.estado[x]["codigo"]+'">'+data.estado[x]["nombre"]+'</option>';
	}
	cadena +="</select>";

	$(cadena).appendTo('.clase');
	activarSelect();					
}

/**
* Funcion Java Script que permite listar Todas las personas
* para que luego sean mostradas. los datos son enviados
* por ajax para que se haga la consulta a la base de datos y mostrar 
* los resultados en la funcion montarPersona().
*/
function verPersona(){
	var arr = Array("m_modulo"	,	"persona",
					"m_accion"	,	"listar",
					"estado"	,	$("#selectEstado").val(),
					"pnf"		,	$("#selectPNF").val(),
					"instituto"	,	$("#selectInstituto").val()
					);
		
	ajaxMVC(arr,montarPersona,error);
}

/**
* Funcion Java Script que permite listar Todos los empleado
* para que luego sean mostradas. los datos son enviados
* por ajax para que se haga la consulta a la base de datos y mostrar 
* los resultados en la funcion montarPersona().
*/
function verPersonaEmpleado(){
	var arr = Array("m_modulo"	,	"persona",
					"m_accion"	,	"listar",
					"estado"	,	$("#selectEstado").val(),
					"pnf"		,	$("#selectPNF").val(),
					"instituto"	,	$("#selectInstituto").val(),
					"tipo_persona",	"empleado"
					);
		
	ajaxMVC(arr,montarPersona,error);
}

/**
* Funcion Java Script que permite listar Todos los estudiantes
* para que luego sean mostradas. los datos son enviados
* por ajax para que se haga la consulta a la base de datos y mostrar 
* los resultados en la funcion montarPersona().
*/
function verPersonaEstudiante(){
	var arr = Array("m_modulo"	,	"persona",
					"m_accion"	,	"listar",
					"estado"	,	$("#selectEstado").val(),
					"pnf"		,	$("#selectPNF").val(),
					"instituto"	,	$("#selectInstituto").val(),
					"tipo_persona",	"estudiante"
					);
		
	ajaxMVC(arr,montarPersona,error);
}

/**
* Funcion Java Script que permite mostrar una tabla con
* las personas y es concatenado a una tabla en la vista HTML
*/
function montarPersona(data){
	
	
	cadena="";
	cadena+'<tbody id="listarPersona">';
	for(var x=0; x<data.persona.length; x++)
	{
		if(data.persona[x]['apellido2']!=null)
			var nombre=data.persona[x]['apellido2'];
		else
			var nombre="";

		if(data.persona[x]['nombre2']!=null)
			var apellido=data.persona[x]['nombre2'];
		else
			var apellido="";
		cadena+="<tr>";
		cadena+="<td><input id='cod_persona' type='radio' name='cod_persona' value='"+data.persona[x]['codigo']+"'>"+data.persona[x]['codigo']+"</td>";
		cadena+="<td>"+data.persona[x]['cedula']+"</td>";
		cadena+="<td>"+data.persona[x]['apellido1']+" "+nombre+"</td>";
		cadena+="<td>"+data.persona[x]['nombre1']+" "+apellido+"</td>";
		cadena+="<td>"+data.persona[x]['cor_personal']+"</td>";
	}
	cadena+"</tbody>";

	$("#listarPersona").remove();
	$(cadena).appendTo('#tabla');	

}

/**
* Funcion Java Script que permite modificar la informacion
* de una persona de la base de datos. Los Datos son enviados
* por ajax.
*/
function modificarPersona(){
	var arr = Array("m_modulo"	,	"persona",
					"m_accion"	,	"modificar",	
					"codPersona", $('input:radio[name=cod_persona]:checked').val());	

		ajaxMVC(arr,montarModificarPersona,error);

}

function succMontarModificarPersona(data)
{

	if(data.estatus>0)
		montarModificarPersona(data);
	else
		mostrarMensaje(data.mensaje,4);
}

function montarModificarPersona(data){

	alert("hola");
	//document.location.href = "index.php?m_modulo=persona&m_formato=html5&m_accion=listar&m_vista=Agregar";
	
}

/**
* Funcion Java Script que permite guardar los datos de a una persona
* para que luego sean guaradosde la base de datos. Los Datos son enviados
* por ajax.
*/

function guardarPersona(){
	var arr = Array("m_modulo"	,	"persona",
					"m_accion"	,	"agregar",
					"cedPersona",	$("#ced_persona").val(),
					"rifPersona",	$("#rif_persona").val(),
					"nombre1"	,	$("#nombre1").val(),
					"nombre2"	,	$("#nombre2").val(),
					"apellido1"	,	$("#apellido1").val(),
					"apellido2"	,	$("#apellido2").val(),
					"telefono1"	,	$("#telefono1").val(),
					"telefono2"	,	$("#telefono2").val(),
					"corPersonal"	,	$("#cor_personal").val(),
					"corInstitucional"	,	$("#cor_institucional").val(),
					"discapacidad"	,	$("#discapacidad").val(),
					"direccion"	,	$("#direccion").val(),
					"obsPersona"	,	$("#obs_persona").val(),
					"sexo"		,	$('#sexo').val(),
					"tipSangre" ,	$('#tip_sangre').val(),
					"hijo"		,	$('#hijo').val(),
					"estCivil"	,	$('#est_civil').val(),
					"nacionalidad",	$('#nacionalidad').val(),
					"fecNacimiento",$('#fecNacimiento').val(),
					"codigo",		$('#codigo').val()


					);
		
	ajaxMVC(arr,succAgregarPersona,error);
}

/**
* Funcion Java Script que permite borrar a una persona
* de la base de datos. Los Datos son enviados
* por ajax.
*/
function borrarPersona(){ //activoo controlador.

	var arr = Array("m_modulo"	,	"persona",
					"m_accion"	,	"eliminar",
					"cod_persona",  $("#cod_persona").val()									
					);
		
	ajaxMVC(arr,succMontarEliminarPersona,error);

}

function succMontarEliminarPersona (data){

	if(data.estatus>0)
		montarEliminarPersona(data);
	else
		mostrarMensaje(data.mensaje,4);

}

function montarEliminarPersona(data){

	
}

function succAgregarPersona(data){
	mostrarMensaje(data.mensaje, 1);
	
}

/**
* Funcion Java Script que permite mostrar un mensaje de error.
*/
function error(data){	
	console.log(data);
	mostrarMensaje("Error de comunicación con el servidor.",2);
}